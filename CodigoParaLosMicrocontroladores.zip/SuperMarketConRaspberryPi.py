from machine import Pin, PWM
import utime

# Configuración de pines
SERVO_PIN = 0
IR_PIN = 1
LED_PIN_1 = 2
LED_PIN_2 = 3
LED_PIN_3 = 4
LED_PIN_4 = 5  # Nuevo LED en GP5

# Configuración del servo
servo = PWM(Pin(SERVO_PIN))
servo.freq(50)

# Configuración del sensor IR
ir_sensor = Pin(IR_PIN, Pin.IN)

# Configuración de los LEDs
led1 = Pin(LED_PIN_1, Pin.OUT)
led2 = Pin(LED_PIN_2, Pin.OUT)
led3 = Pin(LED_PIN_3, Pin.OUT)
led4 = Pin(LED_PIN_4, Pin.OUT)  # Configuración del nuevo LED

# Constantes
DEBOUNCE_TIME = 50  # milisegundos
DOOR_OPEN_TIME = 5000  # milisegundos (5 segundos)
LED_ON_TIME = 10000  # milisegundos (30 segundos)

def set_servo_angle(angle):
    duty = int(((angle + 45) * 100000) // 9)
    servo.duty_ns(duty)

def open_door():
    set_servo_angle(0)  # 0 grados para abrir
    print("Puerta abierta")

def close_door():
    set_servo_angle(90)  # 90 grados para cerrar
    print("Puerta cerrada")

def turn_on_leds():
    led1.on()
    led2.on()
    led3.on()
    led4.on()  # Encender el nuevo LED
    print("LEDs encendidos")

def turn_off_leds():
    led1.off()
    led2.off()
    led3.off()
    led4.off()  # Apagar el nuevo LED
    print("LEDs apagados")

def main():
    door_open = False
    leds_on = False
    last_trigger_time = 0
    last_ir_state = 0
    led_start_time = 0

    while True:
        current_time = utime.ticks_ms()
        ir_state = ir_sensor.value()
        
        # Verificar cambio de estado con debounce
        if ir_state != last_ir_state:
            if utime.ticks_diff(current_time, last_trigger_time) > DEBOUNCE_TIME:
                if ir_state == 1 and not door_open:
                    print("Objeto detectado por IR")
                    open_door()
                    if not leds_on:
                        turn_on_leds()
                        led_start_time = current_time
                        leds_on = True
                    door_open = True
                    last_trigger_time = current_time
                last_ir_state = ir_state
        
        # Cerrar la puerta después del tiempo establecido
        if door_open and utime.ticks_diff(current_time, last_trigger_time) > DOOR_OPEN_TIME:
            close_door()
            door_open = False
        
        # Apagar los LEDs después de 30 segundos
        if leds_on and utime.ticks_diff(current_time, led_start_time) > LED_ON_TIME:
            turn_off_leds()
            leds_on = False
        
        utime.sleep_ms(10)  # Pequeña pausa para no saturar el procesador

if __name__ == "__main__":
    close_door()  # Asegurarse de que la puerta esté cerrada al inicio
    main()